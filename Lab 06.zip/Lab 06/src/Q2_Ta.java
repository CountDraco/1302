public class Q2_Ta {

    public static void main(String[] args) {

        double result = pay(5.5, 6);
        System.out.println(result);
    }

    public static double pay(double salary, int hours) {
        return (salary * hours);
    }
}
