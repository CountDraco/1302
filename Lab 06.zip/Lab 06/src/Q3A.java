public class Q3A {

    public static void main(String[] args)
    {
        printResults(21, 3.3f);
    }

    public static void printResults(int age, float gpa)
    {

        printAge(age);
        printtwiceage(age);
        printthreeage(age);
        printhalfage(age);
        printgpa(gpa);
        printhalfgpa(gpa);

    }

    public static void printAge(int age)
    {
        System.out.println("My age is " + age);
    }

    public static void printtwiceage(int age)
    {
        System.out.println("Twice my age is " + (age * 2));
    }

    public static void printthreeage(int age)
    {
        System.out.println("Three times my age is " + (age * 3));
    }

    public static void printhalfage(int age)
    {
        System.out.println("Half my age is " + (age / 2.0f));
    }

    public static void printgpa(float gpa)
    {
        System.out.println("My gpa is  " + gpa);
    }

    public static void printhalfgpa(float gpa)
    {
        System.out.println("Half my gpa is " + (gpa / 2));
    }


}
