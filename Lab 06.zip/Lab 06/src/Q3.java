import java.math.*;

public class Q3
{
    public static void main(String[] args)
    {
        printResults(21, 3.3f);
    }

    public static void printResults(int age, float gpa) {

        System.out.println("My age is " + age);
        System.out.println("Twice my age is " + (age * 2));
        System.out.println("Three times my age is " + (age * 3));
        System.out.println("Half my age is " + (age / 2.0f));
        System.out.println("My gpa is  " + gpa);
        System.out.println("Half my gpa is " + (gpa / 2));

    }

}
