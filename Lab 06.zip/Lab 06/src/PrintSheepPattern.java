public class PrintSheepPattern {

    public static void main(String[] args)
    {
        System.out.println("         '__'");
        System.out.println("         (oo)");
        System.out.println("     /========//");
        System.out.println("    / || @@ ||");
        System.out.println("   * ||----||");
        System.out.println("     VV    VV");
        System.out.println("     '' ''");
        
    }

}
